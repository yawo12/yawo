from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from yawoapp.forms import UserForm, VendorForm
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User

# Create your views here.

def home(request):
    return redirect(vendor_home)

@login_required(login_url='/vendor/sign-in/')
def vendor_home(request):
    return render(request, 'vendor/home.html', {})

def vendor_sign_up(request):
    user_form = UserForm()
    vendor_form = VendorForm()

    if request.method == "POST":
        user_form = UserForm(request.POST)
        vendor_form = VendorForm(request.POST, request.FILES)

        if user_form.is_valid() and vendor_form.is_valid():
            new_user = User.objects.create_user(**user_form.cleaned_data)
            new_vendor = vendor_form.save(commit=False)
            new_vendor.user = new_user
            new_vendor.save()

            login(request, authenticate(
                username = user_form.cleaned_data["username"],
                password = user_form.cleaned_data["password"]
            ))

            return redirect(vendor_home)

    return render(request, 'vendor/sign_up.html', {
        "user_form": user_form,
        "vendor_form": vendor_form
    })
