from django.apps import AppConfig


class YawoappConfig(AppConfig):
    name = 'yawoapp'
