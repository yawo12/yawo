from django.contrib import admin

# Register your models here.
from yawoapp.models import Vendor

admin.site.register(Vendor)
